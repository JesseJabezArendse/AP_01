STLINK_COMPORT = auto_COMPORT();

function STLINK_COMPORT = auto_COMPORT()
    Skey = 'HKEY_LOCAL_MACHINE\HARDWARE\DEVICEMAP\SERIALCOMM';
    % Find connected serial devices and clean up the output
    [~, list] = dos(['REG QUERY ' Skey]);
    list = strread(list,'%s','delimiter',' ');
    coms = 0;
    for i = 1:numel(list)
      if strcmp(list{i}(1:3),'COM')
          if ~iscell(coms)
              coms = list(i);
          else
              coms{end+1} = list{i};
          end
      end
    end
    key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\USB\';
    % Find all installed USB devices entries and clean up the output
    [~, vals] = dos(['REG QUERY ' key ' /s /f "FriendlyName" /t "REG_SZ"']);
    vals = textscan(vals,'%s','delimiter','\t');
    vals = cat(1,vals{:});
    out = 0;
    % Find all friendly name property entries
    for i = 1:numel(vals)
      if strcmp(vals{i}(1:min(12,end)),'FriendlyName')
          if ~iscell(out)
              out = vals(i);
          else
              out{end+1} = vals{i};
          end
      end
    end
    % Compare friendly name entries with connected ports and generate output
    for i = 1:numel(coms)
      match = strfind(out,[coms{i},')']);
      ind = 0;
      for j = 1:numel(match)
          if ~isempty(match{j})
              ind = j;
          end
      end
      if ind ~= 0
          com = str2double(coms{i}(4:end));
    % Trim the trailing ' (COM##)' from the friendly name - works on ports from 1 to 99
          if com > 9
              length = 8;
          else
              length = 7;
          end
          devs{i,1} = out{ind}(27:end-length);
          devs{i,2} = "COM"+string(com);
      end
    end
    
    for i = size(devs,1)
        if devs{i,1} == 'STMicroelectronics STLink Virtual COM Port';
            STLINK_COMPORT = devs{i,2}
        end
    end
end

function drive_name = DriveName( drive_letter ) 
    cmd_str = sprintf( 'vol %s:', drive_letter );
    [~,msg] = system( cmd_str );
    cac = strsplit( msg, '\n' );
    drive_name = regexp( cac{1}, '(?<= is ).+$', 'match', 'once' );
end


function ret = getdrives(varargin)
%GETDRIVES  Get the drive letters of all mounted filesystems.
%   F = GETDRIVES returns the roots of all mounted filesystems as a cell
%   array of char arrays.
%   
%   On Windows systems, this is a list of the names of all single-letter 
%   mounted drives.
%
%   On Unix systems (including Macintosh) this is the single root
%   directory, /.
% 
%   F = GETDRIVES('-nofloppy') does not scan for the a: or b: drives on
%   Windows, which usually results in annoying grinding sounds coming from
%   the floppy drive.
%   
%   F = GETDRIVES('-twoletter') scans for both one- AND two-letter drive
%   names on Windows.  While two-letter drive names are technically supported,
%   their presence is in fact rare, and slows the search considerably.
%
%   Note that only the names of MOUNTED volumes are returned.  In 
%   particular, removable media drives that do not have the media inserted 
%   (such as an empty CD-ROM drive) are not returned.
%
%   See also EXIST, COMPUTER, UIGETFILE, UIPUTFILE.

%   Copyright 2001-2009 The MathWorks, Inc.

% Short-circut on non-Windows machines.
if ~ispc
    ret = {'/'};
    return;
end

twoletter = false;
nofloppy = false;

% Interpret optional arguments
for i = 1:nargin
    if strcmp('-nofloppy', varargin{i}), nofloppy = true; end
    if strcmp('-twoletter', varargin{i}), twoletter = true; end
end

% Initialize return cell array
ret = {};

% Handle -nofloppy flag, or lack thereof.
startletter = 'a';
if nofloppy
    startletter = 'c';
end

% Look for single-letter drives, starting at a: or c: as appropriate
for i = double(startletter):double('z')
    if exist(['' i ':\'], 'dir') == 7
        ret{end+1} = [i ':\']; %#ok<AGROW>
    end
end

end